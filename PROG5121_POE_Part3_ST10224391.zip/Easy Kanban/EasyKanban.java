import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EasyKanban {
    private static String name;
    private static String surname;
    private static String username;
    private static String password;
    private static List<Task> tasks = new ArrayList<>();
    private static int taskNumber = 0;
    private static double totalTaskDuration = 0;

    /**
     * Starts the EasyKanban application.
     */
    public void start() {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban!");

        boolean isRegistered = false;

        while (!isRegistered) {
            JOptionPane.showMessageDialog(null, "In order to use EasyKanban, you need to be logged in.");

            while (true) {
                username = JOptionPane.showInputDialog("Choose a Username (must be more than 5 letters and contain an underscore):");
                if (checkUserName()) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
                }
            }

            while (true) {
                password = JOptionPane.showInputDialog("Choose a Password:\n- Must contain a capital letter\n- Minimum of 8 characters\n- Must Contain A Number\n- Contains Atleast 1 Special Character");
                if (checkPasswordComplexity()) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
                }
            }

            name = JOptionPane.showInputDialog("Enter Your Name:");
            surname = JOptionPane.showInputDialog("Enter Your Surname:");

            if (registerUser()) {
                isRegistered = true;
                JOptionPane.showMessageDialog(null, "Registration successful.\n\nWelcome to EasyKanban, " + name + " " + surname + "!");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to register user. Please try again.");
            }
        }

        JOptionPane.showMessageDialog(null, "Please sign in:");

        boolean isSignedIn = false;

        while (!isSignedIn) {
            String logOnUsername = JOptionPane.showInputDialog("Enter username:");
            String logOnPassword = JOptionPane.showInputDialog("Enter password:");

            if (loginUser(logOnUsername, logOnPassword)) {
                isSignedIn = true;
                JOptionPane.showMessageDialog(null, "Login successful.\n\nWelcome back " + name + " " + surname + "!");
            } else {
                JOptionPane.showMessageDialog(null, "Username or password incorrect. Please try again.");
            }
        }

        int choice = 0;

        while (choice != 8) {
            choice = displayMenu();

            switch (choice) {
                case 1:
                    addTasks();
                    break;
                case 2:
                    displayDoneTasks();
                    break;
                case 3:
                    displayLongestTask();
                    break;
                case 4:
                    searchTaskByName();
                    break;
                case 5:
                    searchTasksByDeveloper();
                    break;
                case 6:
                    deleteTask();
                    break;
                case 7:
                    displayAllTasks();
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "Exiting...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Displays the main menu and returns the user's choice.
     *
     * @return The user's choice as an integer.
     */
    public int displayMenu() {
        String choiceStr = JOptionPane.showInputDialog("Menu:\n1. Add Tasks\n2. Show Tasks with Status 'Done'\n3. Show Task with Longest Duration\n4. Search Task by Name\n5. Search Tasks by Developer\n6. Delete a Task\n7. Display All Tasks\n8. Quit\n\nEnter your choice:");
        return Integer.parseInt(choiceStr);
    }

    /**
     * Adds tasks to the task list.
     */
    public static void addTasks() {
        String taskCountStr = JOptionPane.showInputDialog("Adding tasks:\nHow many tasks would you like to enter?");

        if (taskCountStr == null) {
            JOptionPane.showMessageDialog(null, "Task addition canceled.");
            return;
        }

        int taskCount = 0;

        try {
            taskCount = Integer.parseInt(taskCountStr);
            if (taskCount < 0) {
                JOptionPane.showMessageDialog(null, "Invalid task count. Please enter a non-negative integer.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer.");
            return;
        }
        for (int i = 0; i < taskCount; i++) {
            String taskName = "";

            while (true) {
                taskName = JOptionPane.showInputDialog("Adding Task #" + (i + 1) + ":\nEnter Task Name:");

                if (taskName.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Task Name can't be left empty. Let's try that again.");
                } else {
                    break;
                }
            }

            String taskDescription = "";

            while (true) {
                taskDescription = JOptionPane.showInputDialog("Enter Task Description:");
                if (taskDescription.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Task Description can't be left empty. Let's try that again.");
                } else if (taskDescription.length() > 50) {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                } else {
                    break;
                }
            }

            String developerFirstName;
            String developerLastName;

            while (true) {
                developerFirstName = JOptionPane.showInputDialog("Enter Developer First Name:");
                if (developerFirstName.length() > 0) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Developer First Name cannot be empty. Please try again.");
                }
            }

            while (true) {
                developerLastName = JOptionPane.showInputDialog("Enter Developer Last Name:");
                if (developerLastName.length() > 0) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Developer Last Name cannot be empty. Please try again.");
                }
            }

            double taskDuration;
            while (true) {
                String taskDurationInput = JOptionPane.showInputDialog("Enter Task Duration (in hours):");
                if (taskDurationInput.length() > 0) {
                    try {
                        taskDuration = Double.parseDouble(taskDurationInput);
                        break;
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input for task duration. Please enter a valid number.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Task Duration cannot be empty. Please try again.");
                }
            }

            String taskID = Task.createTaskID(taskName, developerFirstName);

            String taskStatus = getTaskStatus();

            Task task = new Task(taskName, taskNumber, taskDescription, developerFirstName, developerLastName, taskDuration, taskID, taskStatus);
            tasks.add(task);

            totalTaskDuration += taskDuration;

            JOptionPane.showMessageDialog(null, "Task #" + (i + 1) + " successfully added!\n\n" + task.printTaskDetails());
        }
    }

/**
 * Creates a unique task ID based on the task name and developer's first name.
 *
 * @param taskName            The task name.
 * @param developerFirstName  The developer's first name.
 * @return                    The generated task ID.
 */
public static String createTaskID(String taskName, String developerFirstName) {
    String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerFirstName.substring(developerFirstName.length() - 3).toUpperCase();
    taskNumber++;
    return taskID;
}

/**
 * Displays the tasks with the status "Done".
 */
public static void displayDoneTasks() {
    StringBuilder doneTasksInfo = new StringBuilder("\nTasks with Status 'Done':\n");
    boolean found = false;

    for (Task task : tasks) {
        if (task.getTaskStatus().equalsIgnoreCase("Done")) {
            doneTasksInfo.append(task.getTaskName()).append(" (Developer: ").append(task.getDeveloperFirstName()).append(")\n");
            found = true;
        }
    }

    if (found) {
        JOptionPane.showMessageDialog(null, doneTasksInfo.toString());
    } else {
        JOptionPane.showMessageDialog(null, "No tasks with status 'Done' found.");
    }
}


/**
 * Displays the task with the longest duration.
 */
public static void displayLongestTask() {
    if (tasks.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No tasks found.");
        return;
    }

    double longestDuration = 0;
    String developer = "";

    for (Task task : tasks) {
        if (task.getTaskDuration() > longestDuration) {
            longestDuration = task.getTaskDuration();
            developer = task.getDeveloperFirstName() + " " + task.getDeveloperLastName();
        }
    }

    if (longestDuration > 0) {
        JOptionPane.showMessageDialog(null, "Task with Longest Duration:\nDeveloper: " + developer + "\nDuration: " + longestDuration + " hours");
    } else {
        JOptionPane.showMessageDialog(null, "No tasks found.");
    }
}

/**
 * Searches for a task by its name and displays the task's details.
 */
public static void searchTaskByName() {
    String taskNameToSearch = JOptionPane.showInputDialog("Enter the Task Name to search:");

    if (taskNameToSearch == null || taskNameToSearch.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Invalid input. Please enter a task name.");
        return;
    }

    boolean found = false;

    for (Task task : tasks) {
        if (task.getTaskName().equalsIgnoreCase(taskNameToSearch)) {
            JOptionPane.showMessageDialog(null, "Task Name: " + task.getTaskName() + "\nDeveloper: " + task.getDeveloperFirstName() + " " + task.getDeveloperLastName() + "\nTask Status: " + task.getTaskStatus());
            found = true;
            break;
        }
    }

    if (!found) {
        int choice = JOptionPane.showConfirmDialog(null, "No task found with the given name. Do you want to try again?", "Task Not Found", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            searchTaskByName();
        }
    }
}

/**
 * Searches for tasks assigned to a specific developer and displays their details.
 */
public static void searchTasksByDeveloper() {
    String developerToSearch = JOptionPane.showInputDialog("Enter the Developer's Name to search:");

    if (developerToSearch == null || developerToSearch.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Invalid input. Please enter a developer name.");
        return;
    }

    StringBuilder matchingTasks = new StringBuilder("\nTasks assigned to " + developerToSearch + ":\n");
    boolean found = false;

    for (Task task : tasks) {
        if (task.getDeveloperFirstName().equalsIgnoreCase(developerToSearch) || task.getDeveloperLastName().equalsIgnoreCase(developerToSearch)) {
            matchingTasks.append("Task Name: ").append(task.getTaskName()).append("\nTask Status: ").append(task.getTaskStatus()).append("\n");
            found = true;
        }
    }

    if (found) {
        JOptionPane.showMessageDialog(null, matchingTasks.toString());
    } else {
        int choice = JOptionPane.showConfirmDialog(null, "No tasks found for the given developer. Do you want to try again?", "Tasks Not Found", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            searchTasksByDeveloper();
        }
    }
}

/**
 * Deletes a task by its name.
 */
public static void deleteTask() {
    String taskNameToDelete = JOptionPane.showInputDialog("Enter the Task Name to delete:");

    if (taskNameToDelete == null || taskNameToDelete.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Invalid input. Please enter a task name.");
        return;
    }

    boolean deleted = false;
    int indexToRemove = -1;

    for (int i = 0; i < tasks.size(); i++) {
        Task task = tasks.get(i);
        if (task.getTaskName().equalsIgnoreCase(taskNameToDelete)) {
            indexToRemove = i;
            deleted = true;
            break;
        }
    }

    if (deleted) {
        tasks.remove(indexToRemove);
        JOptionPane.showMessageDialog(null, "Task '" + taskNameToDelete + "' deleted successfully.");
    } else {
        int choice = JOptionPane.showConfirmDialog(null, "No task found with the given name. Do you want to try again?", "Task Not Found", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            deleteTask();
        }
    }
}

/**
 * Displays all tasks and their details.
 */
public static void displayAllTasks() {
    if (tasks.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No tasks found.");
        return;
    }

    StringBuilder tasksInfo = new StringBuilder("\nAll Tasks:\n");

    for (Task task : tasks) {
        tasksInfo.append(task.printTaskDetails());
    }

    JOptionPane.showMessageDialog(null, tasksInfo.toString());
}

/**
 * Checks if the username meets the required format.
 *
 * @return  True if the username is valid, false otherwise.
 */
public boolean checkUserName() {
    return username.length() > 5 && username.contains("_");
}

/**
 * Checks if the password meets the required complexity.
 *
 * @return  True if the password is valid, false otherwise.
 */
public boolean checkPasswordComplexity() {
    boolean hasCapital = false;
    boolean hasNumber = false;
    boolean hasSpecialChar = false;

    for (char c : password.toCharArray()) {
        if (Character.isUpperCase(c)) {
            hasCapital = true;
        } else if (Character.isDigit(c)) {
            hasNumber = true;
        } else if (!Character.isLetterOrDigit(c)) {
            hasSpecialChar = true;
        }

        if (hasCapital && hasNumber && hasSpecialChar) {
            return password.length() >= 8;
        }
    }

    return false;
}

/**
 * Simulates the registration process.
 *
 * @return  True if the user is registered successfully, false otherwise (placeholder).
 */
public boolean registerUser() {
    return true; // Placeholder for registration logic
}

/**
 * Simulates the login process.
 *
 * @param logOnUsername  The entered username.
 * @param logOnPassword  The entered password.
 * @return               True if the user is logged in successfully, false otherwise.
 */
public boolean loginUser(String logOnUsername, String logOnPassword) {
    // Validate the username and password
    if (logOnUsername.equals(username) && logOnPassword.equals(password)) {
        return true;
    } else {
        return false;
    }
}

/**
 * Displays a dialog to select the task status and returns the selected status.
 *
 * @return  The selected task status.
 */
public static String getTaskStatus() {
    String[] options = {"To Do", "Doing", "Done"};
    int choice = JOptionPane.showOptionDialog(null, "Select the Task Status:", "Task Status", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

    switch (choice) {
        case 0:
            return "To Do";
        case 1:
            return "Doing";
        case 2:
            return "Done";
        default:
            return "";
    }
}
}
