public class Main {

    public static void main(String[] args) {
        EasyKanban easyKanban = new EasyKanban();
            easyKanban.start();
    }
}

//Unit Tests