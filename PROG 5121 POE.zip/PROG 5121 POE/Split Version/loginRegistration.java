// Book:
// Bloch, J. (2008). Effective Java (2nd ed.). Addison-Wesley Professional.

// Journal Article:
// Nguyen, T. T., Nguyen, T. N., Nguyen, Q. V., & Nguyen, T. H. (2019). A novel approach for intelligent tutoring systems based on cognitive load theory. IEEE Access, 7, 125384-125397.

// Conference Proceedings:
// Tan, X., Wang, T., & Wu, C. (2019, July). Application of Java language in computer science teaching. In 2019 International Conference on Educational Innovation and Philosophical Inquiries (ICEIPI 2019) (pp. 192-195). Atlantis Press.

import java.util.Scanner;

public class LoginRegistration {
    
    private static String name;
    private static String surname;
    private static String username;
    private static String password;
    
    public static void registerUser() {
        Scanner scanner = new Scanner(System.in);
        boolean isRegistered = false;

        while (!isRegistered) {
            System.out.println("\nIn Order To Use EasyKanban, You Need To Be Logged In.");

            System.out.print("\nChoose A Username \n(must be more than 5 letters and contain an underscore)\nEnter Username: ");
            username = scanner.nextLine();

            if (!checkUserName()) {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
                continue;
            }

            System.out.print("\n\n\nChoose A Password \n- Must contain a capital letter \n- Minimum of 8 characters \n- Must Contain A Number \n- Contains Atleast 1 Special Character\n\nEnter Password: ");
            password = scanner.nextLine();

            if (!checkPasswordComplexity()) {
                System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
                continue;
            }

            System.out.print("\nEnter Your Name: ");
            name = scanner.nextLine();

            System.out.print("Enter Your Surname: ");
            surname = scanner.nextLine();

            isRegistered = true;
            System.out.println("Registration successful. Welcome to EasyKanban, " + name + " " + surname + "!");
        }
        scanner.close();
    }

    public static void loginUser() {
        Scanner scanner = new Scanner(System.in);
        boolean isSignedIn = false;

        while (!isSignedIn) {
            System.out.print("Enter username: ");
            String logOnUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String logOnPassword = scanner.nextLine();

            if (login(logOnUsername, logOnPassword)) {
                isSignedIn = true;
                System.out.println("Login successful. Welcome back " + name + " " + surname + "!");
            } else {
                System.out.println("Username or password incorrect, please try again.");
            }
        }
        scanner.close();
    }

    private static boolean checkUserName() {
        if (username.contains("_") && username.length() <= 5) {
            return true;
        }
        return false;
    }

    private static boolean checkPasswordComplexity() {
        if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*[0-9].*") && password.matches(".*[^a-zA-Z0-9].*")) {
            return true;
        }
        return false;
    }

    private static boolean login(String loginUsername, String loginPassword) {
        if (loginUsername.equals(username) && loginPassword.equals(password)) {
            return true;
        }
        return false;
    }
}
