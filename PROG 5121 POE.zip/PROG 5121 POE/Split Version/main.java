// Book:
// Bloch, J. (2008). Effective Java (2nd ed.). Addison-Wesley Professional.

// Journal Article:
// Nguyen, T. T., Nguyen, T. N., Nguyen, Q. V., & Nguyen, T. H. (2019). A novel approach for intelligent tutoring systems based on cognitive load theory. IEEE Access, 7, 125384-125397.

// Conference Proceedings:
// Tan, X., Wang, T., & Wu, C. (2019, July). Application of Java language in computer science teaching. In 2019 International Conference on Educational Innovation and Philosophical Inquiries (ICEIPI 2019) (pp. 192-195). Atlantis Press.

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LoginRegistration loginRegistration = new LoginRegistration();

        System.out.println("Welcome to EasyKanban!\n");

        boolean isRegistered = false;

        while (!isRegistered) {
            System.out.println("\nIn Order To Use EasyKanban, You Need To Be Logged In.");

            System.out.print("\nChoose A Username \n(must be more than 5 letters and contain an underscore)\nEnter Username: ");
            String username = scanner.nextLine();

            System.out.print("\n\n\nChoose A Password \n- Must contain a capital letter \n- Minimum of 8 characters \n- Must Contain A Number \n- Contains Atleast 1 Special Character\n\nEnter Password: ");
            String password = scanner.nextLine();

            System.out.print("\nEnter Your Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Your Surname: ");
            String surname = scanner.nextLine();

            if (loginRegistration.checkUserName(username) && loginRegistration.checkPasswordComplexity(password)) {
                isRegistered = true;
                System.out.println(loginRegistration.registerUser(username, password, name, surname));
            } else {
                if (!loginRegistration.checkUserName(username)) {
                    System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
                } 
                if (!loginRegistration.checkPasswordComplexity(password)) {
                    System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
                }
            }
        }

        System.out.println("\nPlease sign in:");

        boolean isSignedIn = false;

        while (!isSignedIn) {
            System.out.print("Enter username: ");
            String logOnUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String logOnPassword = scanner.nextLine();

            if (loginRegistration.loginUser(logOnUsername, logOnPassword)) {
                isSignedIn = true;
                System.out.println(loginRegistration.returnLogOnStatus(true, logOnUsername, logOnPassword));
            } else {
                System.out.println(loginRegistration.returnLogOnStatus(false, "", ""));
            }
        }

        scanner.close();
    }

}
