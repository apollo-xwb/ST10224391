import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class EasyKanbanTest {
    
    @Test
    public void testCheckUserName() {
        String name = "kyl_1";
        String invalidName = "kyle!!!!!!!";
        String expected = "Registration successful. Welcome to EasyKanban, John Doe!";
        String invalidExpected = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        
        EasyKanban.name = "John";
        EasyKanban.surname = "Doe";
        EasyKanban.username = name;
        EasyKanban.password = "Ch&&sec@ke99!";
        
        assertEquals(expected, EasyKanban.registerUser());
        
        EasyKanban.username = invalidName;
        assertEquals(invalidExpected, EasyKanban.registerUser());
    }
    
    @Test
    public void testCheckPasswordComplexity() {
        String validPassword = "Ch&&sec@ke99!";
        String invalidPassword = "password";
        
        assertTrue(EasyKanban.checkPasswordComplexity(validPassword));
        assertFalse(EasyKanban.checkPasswordComplexity(invalidPassword));
    }
    
    @Test
    public void testLoginUser() {
        EasyKanban.name = "John";
        EasyKanban.surname = "Doe";
        EasyKanban.username = "kyl_1";
        EasyKanban.password = "Ch&&sec@ke99!";
        
        assertTrue(EasyKanban.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertFalse(EasyKanban.loginUser("invalid_user", "invalid_password"));
    }
}
